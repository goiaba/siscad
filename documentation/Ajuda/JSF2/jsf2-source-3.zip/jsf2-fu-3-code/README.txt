To run the places application, do the following:

1. Run ant, by just typing ant at the command line. That ant command will create a single file: conf/places-gmaps.xml.
2. Copy conf/places-gmaps.xml to the $TOMCAT_HOME/conf/Catalina/localhost directory. (If that directory doesn't exist, create it)
3. Start Tomcat, and access localhost:8080/places.
