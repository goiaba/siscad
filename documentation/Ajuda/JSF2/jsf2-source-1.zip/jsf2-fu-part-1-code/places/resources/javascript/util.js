function showProjectStage() {
  alert(jsf.getProjectStage());
}

