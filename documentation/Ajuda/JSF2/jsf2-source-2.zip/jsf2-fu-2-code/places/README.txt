To run the places application, you need to change the following:

  YOUR_YAHOO_ID_HERE

To your Yahoo web services ID in MapService.java and WeatherService.java. See the first article in this series for instructions on obtaining that identifier. Then, compile the code (the easiest way is to create an Eclipse project with the Groovy Eclipse plug-in installed), and run the application.

