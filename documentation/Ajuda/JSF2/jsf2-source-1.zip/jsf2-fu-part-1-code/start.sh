cp conf/*.xml $TOMCAT_HOME/conf/Catalina/localhost
$TOMCAT_HOME/bin/catalina.sh jpda start
