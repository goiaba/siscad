function zoomChanging(data) {
  var menuId = data.source.id;
  var progressbarId = menuId.substring(0, menuId.length - "menu".length)
      + "progressbar";

  if (data.name == "begin") {
    Element.hide(menuId);
    Element.show(progressbarId);
  } 
  else if (data.name == "success") {
    Element.show(menuId);
    Element.hide(progressbarId);
    executeScripts(data)
  }
  function executeScripts(data) {
    if(data.name == "success") {
    var rXML = data.responseXML;
    var updates = rXML.getElementsByTagName("update");
    for(var u=0; u<updates.length; u++) {
      var update = updates[u];
      var children = update.childNodes;
      for(var i=0; i<children.length; i++) {
        var child = children[i];
        if(child.nodeType == 4) { // CDATA
          var tmp = document.createElement("span");
          tmp.innerHTML = child.nodeValue;
          var scripts = tmp.getElementsByTagName("script");
          for(var s=0; s<scripts.length; s++) {
            var script = scripts[s].cloneNode(true);
            // document.getElementsByTagName("head")[0].appendChild(script);
            // or:
            eval(script.innerHTML);
          }
        }
      }
    }
      }
  };
//  jsf.ajax.addOnEvent(executeScripts);
}