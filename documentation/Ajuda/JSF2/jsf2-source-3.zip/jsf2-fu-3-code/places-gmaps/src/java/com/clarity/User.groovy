package com.clarity

import javax.faces.context.FacesContext
import javax.faces.bean.ManagedBean
import javax.faces.bean.SessionScoped
import javax.faces.event.ActionEvent
import javax.faces.event.ComponentSystemEvent 
import javax.faces.event.ValueChangeEvent 
import javax.faces.component.UIForm
import javax.faces.component.UIInput 
import javax.faces.application.FacesMessage
 
@ManagedBean()  
@SessionScoped    
        
public class User {	  
  private final String VALID_NAME     = "Hiro";
  private final String VALID_PASSWORD = "jsf";
  
  private String name
  private String password, nameError;
 
  public String getName() { name }
  public void setName(String newValue) { name = newValue }
  
  public void setNameError(String error) {nameError = error}
  public String getNameError() {nameError}
 
  public String getPassword() { return password }
  public void setPassword(String newValue) { password = newValue }  

  public void validateName(ValueChangeEvent e) {
    UIInput nameInput = e.getComponent()
    String name = nameInput.getValue()
    
    if (name.contains("_"))   nameError = "Name cannot contain underscores"
    else if (name.equals("")) nameError = "Name cannot be blank"
    else                      nameError = "" 
  }

  public void validate(ComponentSystemEvent e) {
    UIForm form = e.getComponent() 
    UIInput nameInput = form.findComponent("name")
    UIInput pwdInput = form.findComponent("password")
    
    if ( ! (nameInput.getValue().equals(VALID_NAME) &&
    		pwdInput.getValue().equals(VALID_PASSWORD))) {
      
      FacesContext fc = FacesContext.getCurrentInstance()
      fc.addMessage(form.getClientId(), 
        new FacesMessage("Name and password are invalid. Please try again."))
      fc.renderResponse()
    }
  }
  
  public String login() {
	"/views/places"
  }

  public String logout() {
	name = password = nameError = null;  
	"/views/login"
  }
}