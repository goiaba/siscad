To run the places application, do the following:

1. Copy the following JAR files to places/WEB-INF/lib:

commons-beanutils.jar
commons-codec-1.3.jar
commons-fileupload-1.1.1.jar
commons-httpclient-3.1-alpha1.jar
commons-io-1.2.jar
commons-logging.jar
groovy-all-1.5.6.jar
gwt-servlet.jar
hibernate3.jar
mysql-connector-java-3.1.13-bin.jar

2. Run ant, by just typing ant at the command line. That ant command will create a single file: conf/places.xml.
3. Copy conf/places.xml to the $TOMCAT_HOME/conf/Catalina/localhost directory. (If that directory doesn't exist, create it)
4. Start Tomcat, and access localhost:8080/places.
