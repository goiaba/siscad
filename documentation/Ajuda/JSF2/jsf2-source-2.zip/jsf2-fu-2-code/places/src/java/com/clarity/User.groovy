package com.clarity

import javax.faces.context.FacesContext
import javax.faces.bean.ManagedBean
import javax.faces.bean.SessionScoped
import javax.faces.event.ActionEvent
import javax.faces.event.ComponentSystemEvent 
import javax.faces.event.ValueChangeEvent 
import javax.faces.component.UIForm
import javax.faces.component.UIInput 
import javax.faces.application.FacesMessage
 
@ManagedBean()  
@SessionScoped
   
public class User {	    
  private String name
  private String password, nameError
 
  public String getName() { name }
  public void setName(String newValue) { name = newValue }
  
  public void setNameError(String error) {nameError = error}
  public String getNameError() {nameError}

  public String getPassword() { return password }
  public void setPassword(String newValue) { password = newValue }  
  
  public String login() {
	"/views/places"
  }

  public String logout() {
	name = password = nameError = null;  
	"/views/login"
  }

  public String goPlanet() {
	"/views/" + planet
  }
  
  public String getPlanetText() { 
	"/resources/textfiles/" + (planet == null ? "mercury" : planet) + ".txt"
  } 
}
