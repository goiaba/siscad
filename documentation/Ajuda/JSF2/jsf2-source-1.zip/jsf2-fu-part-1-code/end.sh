$TOMCAT_HOME/bin/shutdown.sh
for i in `ls conf`; do echo Removing $i from Tomcat; rm $TOMCAT_HOME/conf/Catalina/localhost/$i; done
